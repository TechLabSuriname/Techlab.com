# slimfit-ecommerce
Check out the video https://www.youtube.com/watch?v=C_nXkrOi9Ig
